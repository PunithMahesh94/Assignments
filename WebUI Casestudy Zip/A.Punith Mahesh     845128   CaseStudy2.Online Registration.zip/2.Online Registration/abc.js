function validateform(){  
var name=document.myform.name.value;  
var password=document.myform.password.value; 
var rpassword=document.myform.retypepassword.value; 
var mobile=document.myform.mobile.value;   
  
if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}